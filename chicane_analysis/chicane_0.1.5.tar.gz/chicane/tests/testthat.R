library(testthat)
library(chicane)

test_check("chicane")
